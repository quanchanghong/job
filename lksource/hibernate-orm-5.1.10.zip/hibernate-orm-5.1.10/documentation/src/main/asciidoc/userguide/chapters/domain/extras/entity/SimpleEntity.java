@Entity
public class Simple {
    ...
}