@Entity
public class MyEntity {

    @Id
    public Integer id;

    ...
}